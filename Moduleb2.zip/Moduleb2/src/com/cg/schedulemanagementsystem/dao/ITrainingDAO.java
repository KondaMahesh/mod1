package com.cg.schedulemanagementsystem.dao;

import java.util.List;

import com.cg.schedulemanagementsystem.dto.Client;


public interface ITrainingDAO {
	
	public List<Client> getAllDetail();

}
